<?php
  
       
        $conn = mysqli_connect("localhost", "root", "", "portfolio");
          
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. " );
        }
          
        // Taking all 5 values from the form data(input)
        $name =  $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $subject =  $_REQUEST['subject'];
        $message = $_REQUEST['message'];
     
          
        // Performing insert query execution
        
        $sql = "INSERT INTO contact (name, email, subject, message)  VALUES ('$name', 
            '$email','$subject','$message')";
          
        if(mysqli_query($conn, $sql)){
            echo "<h3>Your message has been submitted.</h3>"; 
  
        } else{
            echo " Something Went Wrong. " 
                . mysqli_error($conn);
        }
          
        // Close connection
        mysqli_close($conn);
        ?>